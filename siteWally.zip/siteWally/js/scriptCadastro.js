var senha = document.getElementById('senha');
var confirSenha = document.getElementById('confirmarsenha');
const icon = document.getElementById('fa fa-eye');

var nome = document.getElementById('nome');
var email = document.getElementById('email');
var senha = document.getElementById('senha');
var confirmSenha = document.getElementById('confirmSenha');

/* função para mostrar senha na página de cadastro */
function mostrarSenha(){
    if(senha.type === 'password'){
        senha.setAttribute('type','text');
        icon.classList.add('hide')
    }else{
        senha.setAttribute('type', 'password');
        icon.classList.remove('hide')
    }
}

/* função para mostrar confirmação senha na página de cadastro */
function mostrarConfirSenha(){
    if(confirSenha.type === 'password'){
        confirSenha.setAttribute('type','text');
        icon.classList.add('hide')
    }else{
        confirSenha.setAttribute('type', 'password');
        icon.classList.remove('hide')
    }
}

/* função para ver se as senhas conferem */
function validarSenhas(){
    if(senha.value != confirSenha.value){
        confirSenha.setCustomValidity("Senhas não conferem!");
    }else{
        confirSenha.setCustomValidity('');
    }

}
senha.onchange = validarSenhas;
confirSenha.onkeyup = validarSenhas;

/* função para validação de email*/
function validacaoEmail(field) {
    usuario = field.value.substring(0, field.value.indexOf("@")); /* criado para definir: usuário = antes do @ e domínio = depois do @ */
    dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);
    
    if ((usuario.length >=3) && /* tamanho do nome de usuário deve ser maior ou igual a 3 caracter */
        (dominio.length >=3) && /* tamanho do domínio deve ser maior ou igual a 3 caracter */
        (usuario.search("@")==-1) && /* usuário não pode conter  @ */
        (dominio.search("@")==-1) && /* domínio não pode conter @ */
        (usuario.search(" ")==-1) && /* usuário não pode contar espaço em branco */
        (dominio.search(" ")==-1) && /* domínio não pode contar espaço em branco */
        (dominio.search(".")!=-1) && /* domíno precisa contar ponto(.) */
        (dominio.indexOf(".") >=1)&& /* a posição do primeiro ponto tem que ser maior ou igual a 1 */
        (dominio.lastIndexOf(".") < dominio.length - 1)) { /* a posição do ultimo ponto tem que ser menor que o ultimo caracter, deve ser finalizado o domínio por um caracter. */
    document.getElementById("msgemail").innerHTML="<font color= 'green'>E-mail válido";
    }else{
    document.getElementById("msgemail").innerHTML="<font color='red'>E-mail inválido";
    }

}